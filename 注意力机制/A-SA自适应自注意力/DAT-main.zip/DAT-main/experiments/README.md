Place pretrained models in `pretrained_models`.
