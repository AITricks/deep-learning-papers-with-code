# GENERATED VERSION FILE
# TIME: Mon Jul 17 01:59:53 2023
__version__ = '1.3.5'
__gitsha__ = '29e57e3'
version_info = (1, 3, 5)
