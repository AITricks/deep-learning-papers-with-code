"""
WPFormer 模块测试运行脚本
在torchv5环境中运行模块化测试
"""

import torch
import sys
import os

def check_environment():
    """检查运行环境"""
    print("=== 环境检查 ===")
    print(f"Python版本: {sys.version}")
    print(f"PyTorch版本: {torch.__version__}")
    print(f"CUDA可用: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"CUDA版本: {torch.version.cuda}")
        print(f"GPU数量: {torch.cuda.device_count()}")
    print("=" * 20)

def main():
    """主函数"""
    print("WPFormer 模块化测试")
    print("=" * 50)
    
    # 检查环境
    check_environment()
    
    # 导入并运行模块测试
    try:
        from modular_wpformer import test_modules
        test_modules()
    except ImportError as e:
        print(f"导入错误: {e}")
        print("请确保modular_wpformer.py文件在当前目录")
        return False
    except Exception as e:
        print(f"运行错误: {e}")
        return False
    
    print("\n" + "=" * 50)
    print("测试完成! 所有模块都可以正常使用")
    print("=" * 50)
    return True

if __name__ == '__main__':
    success = main()
    if not success:
        sys.exit(1)
