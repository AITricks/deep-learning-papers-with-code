"""
WPFormer 环境设置脚本
用于在Anaconda中创建torchv5环境并安装依赖
"""

import subprocess
import sys
import os

def run_command(command, description):
    """运行命令并显示结果"""
    print(f"\n{'='*50}")
    print(f"执行: {description}")
    print(f"命令: {command}")
    print(f"{'='*50}")
    
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print("✓ 成功!")
        if result.stdout:
            print("输出:", result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print("✗ 失败!")
        print("错误:", e.stderr)
        return False

def setup_environment():
    """设置torchv5环境"""
    print("WPFormer 环境设置")
    print("="*50)
    print("这个脚本将帮你设置torchv5环境")
    print("="*50)
    
    # 检查conda是否可用
    print("\n1. 检查conda是否可用...")
    if not run_command("conda --version", "检查conda版本"):
        print("错误: 未找到conda，请确保已安装Anaconda或Miniconda")
        return False
    
    # 创建torchv5环境
    print("\n2. 创建torchv5环境...")
    if not run_command("conda create -n torchv5 python=3.8 -y", "创建torchv5环境"):
        print("警告: 环境可能已存在，继续...")
    
    # 激活环境并安装PyTorch
    print("\n3. 安装PyTorch和相关依赖...")
    pytorch_install = """
    conda activate torchv5 && 
    conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia -y &&
    pip install numpy matplotlib pillow opencv-python
    """
    
    if not run_command(pytorch_install, "安装PyTorch和依赖"):
        print("请手动执行以下命令:")
        print("conda activate torchv5")
        print("conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia -y")
        print("pip install numpy matplotlib pillow opencv-python")
        return False
    
    print("\n4. 环境设置完成!")
    print("="*50)
    print("使用方法:")
    print("1. 激活环境: conda activate torchv5")
    print("2. 运行测试: python modular_wpformer.py")
    print("="*50)
    
    return True

if __name__ == '__main__':
    setup_environment()
